Aauth V2 Database
-----------------

- First you must create a database.
- Execute sql "Aauth.sql" file in your database
- Don't forget to change database connection setups from application/config/database.php

That's All :) 
